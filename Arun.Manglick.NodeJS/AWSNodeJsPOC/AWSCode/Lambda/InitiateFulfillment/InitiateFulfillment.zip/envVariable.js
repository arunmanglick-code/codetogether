process.env.mySQLHost,
process.env.mySQLUserId,
process.env.mySqLPassword,
process.env.mySQLDatabase
process.env.region
process.env.queueUrl
process.env.emailEndPoint
process.env.emailSender
