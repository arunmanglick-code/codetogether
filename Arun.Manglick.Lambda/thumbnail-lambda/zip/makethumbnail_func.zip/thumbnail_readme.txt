# arun-aws-lambda-master
This Repo will contain lambdas per project

# This Lambda Function is to generate thumbnail of any image posted to S3
# This Lambda is triggered when an object is posted in S3 Bucket

# Make a zip of all files - .js file, node_modules, package.json
# Upload this zip file to AWS Lambda

# To Test, Create an S3 Bucket
# Add Trigger in Lambda from this S3 Bucket
# Upload any image in S3
# As a result, find thumbnail of this image stored back in S3

